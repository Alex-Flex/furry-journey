package com.alexflex.experiments.messengerexample;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.daasuu.bl.ArrowDirection;
import com.daasuu.bl.BubbleLayout;

public class MyChat extends AppCompatActivity {

    LinearLayout msgsLayout;
    ConstraintLayout mainLayout;
    EditText message;
    Button sender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(R.string.app_name);
        mainLayout = findViewById(R.id.main_layout);
        msgsLayout = findViewById(R.id.messages_list);
        message = findViewById(R.id.message);
        sender = findViewById(R.id.send_button);

        //listener для кнопки сообщений
        sender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMessage();
            }
        });

        //реагируем на изменения в текстовом поле
        message.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(message.getText().toString().equals("")){
                    sender.setEnabled(false);
                } else {
                    sender.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    //визуальное отображение отправленного сообщения
    protected void sendMessage(){
        if(!message.getText().toString().equals("")) {
            BubbleLayout bubbleLayout = new BubbleLayout(this);
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(0, 10, 0, 10);
            textView.setLayoutParams(layoutParams);
            textView.setText(message.getText().toString());
            textView.setTextColor(Color.WHITE);
            textView.setPadding(10, 10, 10, 10);
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            layoutParams.gravity = Gravity.END;
            bubbleLayout.setLayoutParams(layoutParams);
            bubbleLayout.setArrowDirection(ArrowDirection.RIGHT);
            bubbleLayout.addView(textView);
            bubbleLayout.setBubbleColor(Color.BLUE);
            msgsLayout.addView(bubbleLayout);
            message.setText("");
        }
    }
}
